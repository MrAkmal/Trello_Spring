create function register(get_name character varying, get_surname character varying, get_phone_number character varying) returns boolean
    language plpgsql
as
$$
declare
    anonymous auth_user%rowtype;
begin
    select * into anonymous from auth_user where name = get_name;

    if get_phone_number = anonymous.phone_number then
        return false;
    else
        insert into auth_user (name, surname, phone_number)
        values (get_name, get_surname, get_phone_number);
        return true;
    end if;
end;
$$;

alter function register(varchar, varchar, varchar) owner to postgres;

